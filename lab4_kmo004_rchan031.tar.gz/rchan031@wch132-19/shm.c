#include "param.h"
#include "types.h"
#include "defs.h"
#include "x86.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"

struct {
  struct spinlock lock;
  struct shm_page {
    uint id;
    char *frame;
    int refcnt;
  } shm_pages[64];
} shm_table;

void shminit() {
  int i;
  initlock(&(shm_table.lock), "SHM lock");
  acquire(&(shm_table.lock));
  for (i = 0; i< 64; i++) {
    shm_table.shm_pages[i].id =0;
    shm_table.shm_pages[i].frame =0;
    shm_table.shm_pages[i].refcnt =0;
  }
  release(&(shm_table.lock));
}

int shm_open(int id, char **pointer) {
	unsigned int flag = 0;
	unsigned int i = 0;
	
	acquire(&(shm_table.lock));
	for(i = 0; i < 64; ++i) {
		if(shm_table.shm_pages[i].id == id) { //if we can find the shared memory
			flag = 1; //skips over next loop
			shm_table.shm_pages[i].refcnt++; //increment refcnt because we are sharing another process
			break;
		}
	}
	
	if(flag == 0) {
		for(i = 0; i < 64; i++) {
			if(shm_table.shm_pages[i].id == 0) { //no shared memory
				break;
			}
		}
		shm_table.shm_pages[i].id = id; //gives us the id of the shared memory of the process
		shm_table.shm_pages[i].frame = kalloc(); //allocates memory at the page we're sharing
		shm_table.shm_pages[i].refcnt = 1; //init refcnt to 1 because now 1 process is running
		memset(shm_table.shm_pages[i].frame, 0, PGSIZE); //sets bytes
	}
	
	mappages(myproc()->pgdir, (void *)PGROUNDUP(myproc()->sz), PGSIZE, V2P(shm_table.shm_pages[i].frame), PTE_W|PTE_U); 
	*pointer = (char *) PGROUNDUP(myproc()->sz);
	myproc()->sz += PGSIZE;
	
	release(&(shm_table.lock));
	return 0; //added to remove compiler warning -- you should decide what to return
}

//kalloc allocates free physical memory at runtime

int shm_close(int id) {
	unsigned int i = 0;
	acquire(&(shm_table.lock));
	
	for (i = 0; i< 64; i++) { //go through shm_table
		if(shm_table.shm_pages[i].id == id) {
			shm_table.shm_pages[i].refcnt--;
		}
		else if(shm_table.shm_pages[i].refcnt <= 0) { //clears table if 0 is reached
			shm_table.shm_pages[i].id = 0;
			shm_table.shm_pages[i].frame = 0;
			shm_table.shm_pages[i].refcnt = 0;
		}
	}



	release(&(shm_table.lock));

	return 0; //added to remove compiler warning -- you should decide what to return
}
